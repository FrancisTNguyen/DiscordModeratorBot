# DadBot
A really, really dumb discord bot. It does the classic dadjoke of "Hi {}, I'm dad!" Whilst renaming that user to {}.

Uses Danny's excellent [discord.py](https://github.com/Rapptz/discord.py) library, requires that and python 3.5.

# Inviting
You can get it [here](https://discordapp.com/oauth2/authorize?client_id=284941193714860032&scope=bot&permissions=201329664) if you really want it. I don't know why you would. All it needs is the manage nicknames premission, as well as message sending.

# Self-Hosting
Sure, why not. I don't get it, but okay. To self host, you need discord.py, and python 3.5, as well as a [bot account](https://discordapp.com/developers/applications/me). Then, make a seperate file called "tokenfile.py", with the line ```TOKEN = '{}'``` where {} is your bot token. 
